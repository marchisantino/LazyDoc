const express = require('express');
const fs = require('fs');
const fsp = require('fs').promises;
const path = require('path');
const multer = require('multer');

const config = JSON.parse(fs.readFileSync(path.join(__dirname, 'config.json'), 'utf8'));

const DOCS_DIR = path.resolve(config.docsDir);
const PORT = config.port || 3000;
const ALLOWED_EXT = ['.md', '.txt', '.pdf', '.html'];

// Assure que le dossier de docs existe
if (!fs.existsSync(DOCS_DIR)) {
    fs.mkdirSync(DOCS_DIR, { recursive: true });
    console.log(`📁 Dossier créé : ${DOCS_DIR}`);
}

const app = express();
app.use(express.json());

// Upload : stockage dans DOCS_DIR, filtrage des extensions
const storage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, DOCS_DIR),
    filename: (req, file, cb) => {
        // Évite les écrasements silencieux : renomme si le fichier existe déjà
        let name = Buffer.from(file.originalname, 'latin1').toString('utf8');
        const ext = path.extname(name).toLowerCase();
        const base = path.basename(name, ext);
        let target = name;
        let i = 1;
        while (fs.existsSync(path.join(DOCS_DIR, target))) {
            target = `${base} (${i})${ext}`;
            i++;
        }
        cb(null, target);
    }
});
const upload = multer({
    storage,
    fileFilter: (req, file, cb) => {
        const ext = path.extname(file.originalname).toLowerCase();
        if (ALLOWED_EXT.includes(ext)) cb(null, true);
        else cb(new Error(`Extension non autorisée : ${ext}`));
    }
});

// --- Sécurité : s'assure que le chemin résolu reste dans DOCS_DIR ---
function safePath(filename) {
    const resolved = path.resolve(DOCS_DIR, filename);
    if (!resolved.startsWith(DOCS_DIR + path.sep) && resolved !== DOCS_DIR) {
        return null;
    }
    return resolved;
}

// Sert le frontend (index.html)
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// --- API REST ---

// Liste des fichiers
app.get('/api/files', async (req, res) => {
    try {
        const entries = await fsp.readdir(DOCS_DIR, { withFileTypes: true });
        const files = entries
            .filter(e => e.isFile() && ALLOWED_EXT.includes(path.extname(e.name).toLowerCase()))
            .map(e => ({ name: e.name, ext: path.extname(e.name).toLowerCase() }))
            .sort((a, b) => a.name.localeCompare(b.name));
        res.json(files);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Lecture d'un fichier texte (md, txt, html)
app.get('/api/files/:filename', async (req, res) => {
    const filePath = safePath(req.params.filename);
    if (!filePath) return res.status(403).json({ error: 'Accès interdit' });
    const ext = path.extname(req.params.filename).toLowerCase();
    if (!ALLOWED_EXT.includes(ext)) return res.status(400).json({ error: 'Extension non autorisée' });
    try {
        if (ext === '.pdf') {
            res.setHeader('Content-Type', 'application/pdf');
            fs.createReadStream(filePath).pipe(res);
        } else {
            const content = await fsp.readFile(filePath, 'utf8');
            res.json({ content });
        }
    } catch (err) {
        res.status(404).json({ error: 'Fichier introuvable' });
    }
});

// Sauvegarde (écrasement) d'un fichier texte
app.put('/api/files/:filename', async (req, res) => {
    const filePath = safePath(req.params.filename);
    if (!filePath) return res.status(403).json({ error: 'Accès interdit' });
    const ext = path.extname(req.params.filename).toLowerCase();
    if (['.md', '.txt', '.html'].includes(ext)) {
        try {
            await fsp.writeFile(filePath, req.body.content, 'utf8');
            res.json({ ok: true });
        } catch (err) {
            res.status(500).json({ error: err.message });
        }
    } else {
        res.status(400).json({ error: 'Édition non autorisée pour ce type' });
    }
});

// Création d'un nouveau fichier vide
app.post('/api/files/new', async (req, res) => {
    const { name } = req.body;
    if (!name) return res.status(400).json({ error: 'Nom requis' });
    const ext = path.extname(name).toLowerCase();
    if (!['.md', '.txt', '.html'].includes(ext)) return res.status(400).json({ error: 'Extension non autorisée' });
    const filePath = safePath(name);
    if (!filePath) return res.status(403).json({ error: 'Accès interdit' });
    if (fs.existsSync(filePath)) return res.status(409).json({ error: 'Ce fichier existe déjà' });
    try {
        await fsp.writeFile(filePath, '', 'utf8');
        res.json({ ok: true, name });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Upload de fichiers
app.post('/api/upload', upload.array('files'), (req, res) => {
    const uploaded = req.files.map(f => ({ name: f.filename }));
    res.json({ uploaded });
});

// Suppression d'un fichier
app.delete('/api/files/:filename', async (req, res) => {
    const filePath = safePath(req.params.filename);
    if (!filePath) return res.status(403).json({ error: 'Accès interdit' });
    try {
        await fsp.unlink(filePath);
        res.json({ ok: true });
    } catch (err) {
        res.status(404).json({ error: 'Fichier introuvable' });
    }
});

app.listen(PORT, () => {
    console.log(`\n🚀 LazyDoc Server lancé !`);
    console.log(`   URL       : http://localhost:${PORT}`);
    console.log(`   Docs      : ${DOCS_DIR}`);
    console.log(`   En réseau : http://<votre-ip>:${PORT}\n`);
});
