# LazyDoc — Version serveur réseau

Votre outil personnel LazyDoc, maintenant accessible à toute l'équipe sur le réseau local (ou internet).

## Prérequis

- [Node.js](https://nodejs.org/) v18 ou plus récent

---

## Installation

```bash
# 1. Décompressez le dossier et placez-vous dedans
cd lazydoc-server

# 2. Installez les dépendances
npm install

# 3. Lancez le serveur
npm start
```

Le terminal affichera l'URL d'accès :
```
🚀 LazyDoc Server lancé !
   URL       : http://localhost:3000
   Docs      : /chemin/vers/vos/docs
   En réseau : http://192.168.x.x:3000
```

---

## Configuration

Éditez le fichier `config.json` :

```json
{
    "port": 3000,
    "docsDir": "./docs"
}
```

| Paramètre | Description |
|-----------|-------------|
| `port`    | Port d'écoute du serveur (défaut : 3000) |
| `docsDir` | Chemin vers le dossier de documents. Peut être absolu (`/home/user/mes-docs`) ou relatif au dossier du projet (`./docs`) |

---

## Utilisation

Ouvrez **http://\<ip-du-serveur\>:3000** dans n'importe quel navigateur du réseau.

### Fonctionnalités

- **Lecture** de fichiers `.md`, `.txt`, `.pdf`, `.html`
- **Recherche** dans les noms et contenus de fichiers (fuzzy search)
- **Édition** et **sauvegarde** des fichiers texte (Ctrl+S)
- **Création** de nouveaux fichiers (bouton `+` en haut à gauche)
- **Import** par glisser-déposer ou clic sur la zone d'import
- **Suppression** (croix au survol de chaque fichier, confirmation requise)
- **Thème** clair/sombre

---

## Lancer au démarrage (optionnel)

### Linux / macOS — avec PM2

```bash
npm install -g pm2
pm2 start server.js --name lazydoc
pm2 save
pm2 startup
```

### Windows — avec PM2

```bash
npm install -g pm2
pm2 start server.js --name lazydoc
pm2 save
```

---

## Structure du projet

```
lazydoc-server/
├── server.js        ← Serveur Express (API REST)
├── config.json      ← Configuration (port, dossier docs)
├── package.json
├── public/
│   └── index.html   ← Interface web
└── docs/            ← Dossier de documents (créé automatiquement)
```
